"""Minimal settings for a read-only LOCAL educational API."""
DEBUG = False
SECRET_KEY = "local-demo-only-no-sessions-or-signing-not-a-production-secret"
ALLOWED_HOSTS = ["localhost", "127.0.0.1", "[::1]"]
ROOT_URLCONF = "bom_demo.urls"
INSTALLED_APPS = []
MIDDLEWARE = ["django.middleware.common.CommonMiddleware"]
DATABASES = {}
USE_TZ = True
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
