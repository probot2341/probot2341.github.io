from django.http import JsonResponse
from django.urls import path
from django.views.decorators.http import require_GET
from .logic import apply_scenario, calculate, load_sample


@require_GET
def kpis(request):
    try:
        data = apply_scenario(load_sample(), request.GET.get("scenario", "base"))
    except ValueError as error:
        return JsonResponse({"error": str(error)}, status=400)
    return JsonResponse(calculate(data))


@require_GET
def health(request):
    return JsonResponse({"status": "ok", "scope": "local educational prototype"})


urlpatterns = [path("api/kpis/", kpis), path("health/", health)]
