"""Single-level BOM planning snapshot, using entirely synthetic inputs."""
from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP
import json
from pathlib import Path


SCENARIOS = {"base": Decimal("1"), "low": Decimal("0.8"), "high": Decimal("1.2")}


def load_sample():
    return json.loads(Path(__file__).with_name("sample_bom.json").read_text(encoding="utf-8"))


def numeric(value, field, *, positive=False):
    # JSON numbers only: reject booleans, numeric strings, NaN, and infinities.
    if type(value) not in (int, float):
        raise ValueError(f"{field} must be a JSON number")
    result = Decimal(str(value))
    if not result.is_finite() or result < 0 or (positive and result == 0):
        raise ValueError(f"{field} must be finite and {'positive' if positive else 'nonnegative'}")
    return result


def unique_rows(rows, key):
    if not isinstance(rows, list) or not rows:
        raise ValueError(f"{key} table must be a nonempty list")
    result = {}
    for row in rows:
        value = row.get(key)
        if not isinstance(value, str) or not value.strip() or value in result:
            raise ValueError(f"{key} must be a unique nonempty string")
        result[value] = row
    return result


def plain(value):
    return int(value) if value == value.to_integral_value() else float(value)


def apply_scenario(data, scenario="base"):
    """Scale original-plan demand, rounding each finished product to whole units."""
    if not isinstance(scenario, str) or scenario not in SCENARIOS:
        raise ValueError("scenario must be base, low, or high")
    result = deepcopy(data)
    products = unique_rows(result["products"], "product_id")
    for product in products.values():
        demand = numeric(product["demand_qty"], "demand_qty")
        product["demand_qty"] = plain(
            (demand * SCENARIOS[scenario]).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
        )
    result["scenario"] = scenario
    return result


def calculate(data):
    if data.get("revision") != "B" or data.get("revision_status") != "approved":
        raise ValueError("This sample accepts only its single approved revision B")
    if data.get("currency") != "USD":
        raise ValueError("This sample accepts only USD")
    scenario = data.get("scenario", "base")
    if not isinstance(scenario, str) or scenario not in SCENARIOS:
        raise ValueError("scenario must be base, low, or high")
    products = unique_rows(data["products"], "product_id")
    components = unique_rows(data["components"], "component_id")
    demand = {key: numeric(row["demand_qty"], "demand_qty") for key, row in products.items()}
    stock = {}
    for key, row in components.items():
        if row.get("unit") != "EA":
            raise ValueError("All components must use EA units; no unit conversion is implemented")
        on_hand = numeric(row["on_hand"], "on_hand")
        reserved = numeric(row["reserved"], "reserved")
        if reserved > on_hand:
            raise ValueError("reserved must not exceed on_hand")
        stock[key] = (on_hand - reserved, numeric(row["unit_cost"], "unit_cost"))
    lines = data["bom"]
    if not isinstance(lines, list) or not lines:
        raise ValueError("bom must be a nonempty list")
    required = {key: Decimal(0) for key in components}
    product_components = {key: set() for key in products}
    seen = set()
    for row in lines:
        product = row.get("product_id")
        component = row.get("component_id")
        if product not in products or component not in components:
            raise ValueError("BOM has a missing or unknown product/component reference")
        if (product, component) in seen:
            raise ValueError("Duplicate product-component BOM line")
        seen.add((product, component))
        qty = numeric(row["qty_per"], "qty_per", positive=True)
        required[component] += demand[product] * qty
        product_components[product].add(component)
    if any(not items for items in product_components.values()):
        raise ValueError("Each product must have at least one BOM line")
    rows = []
    shortages = set()
    total_value = Decimal(0)
    for key in sorted(components):
        available, cost = stock[key]
        shortage = max(required[key] - available, Decimal(0))
        if shortage > 0:
            shortages.add(key)
        value = shortage * cost
        total_value += value
        rows.append({"component_id": key, "name": components[key].get("name", key),
                     "required_qty": plain(required[key]),
                     "available_qty": plain(available), "shortage_qty": plain(shortage),
                     "unit_cost": plain(cost), "shortage_value": plain(value)})
    product_rows = [{"product_id": key, "demand_qty": plain(demand[key]),
                     "has_shortage": bool(demand[key] > 0 and product_components[key] & shortages)}
                    for key in sorted(products)]
    affected = sum(row["has_shortage"] for row in product_rows)
    return {"metadata": {"data_type": "synthetic educational sample", "revision": "B",
                         "revision_status": "approved", "currency": "USD",
                         "scenario": scenario, "demand_multiplier": plain(SCENARIOS[scenario]),
                         "demand_rounding": "nearest whole unit; .5 rounds up",
                         "reservations_assumption": "reserved stock is committed outside this production plan",
                         "scope": "single-level snapshot; no lead times or stock allocation",
                         "outcome": "planning exposure, not realized savings",
                         "approval": "sample checks only; no business sign-off"},
            "components": rows, "products": product_rows,
            "kpis": {"bom_lines": len(lines), "component_count": len(components),
                     "shortage_parts": len(shortages), "affected_products": affected,
                     "product_count": len(products),
                     "products_without_shortage_exposure": len(products) - affected,
                     "shortage_value": plain(total_value)}}
