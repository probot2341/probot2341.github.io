from copy import deepcopy
from django.test import SimpleTestCase, override_settings
from .logic import apply_scenario, calculate, load_sample


@override_settings(ALLOWED_HOSTS=["localhost", "127.0.0.1", "[::1]", "testserver"])
class BomTests(SimpleTestCase):
    def setUp(self):
        self.data = load_sample()

    def test_api_expected_snapshot_and_shared_component_aggregation(self):
        response = self.client.get("/api/kpis/")
        self.assertEqual(response.status_code, 200)
        result = response.json()
        self.assertEqual(result["kpis"], {"bom_lines": 8, "component_count": 6,
            "shortage_parts": 2, "affected_products": 2, "product_count": 3,
            "products_without_shortage_exposure": 1, "shortage_value": 1460})
        c01 = result["components"][0]
        self.assertEqual((c01["required_qty"], c01["available_qty"], c01["shortage_qty"]), (170, 90, 80))
        self.assertEqual([row["has_shortage"] for row in result["products"]], [True, True, False])

    def test_api_all_scenarios_match_component_snapshots(self):
        # Expected tuples are required, available, short, unit cost, shortage value.
        expected = {
            "base": {"demand": [40, 30, 20], "count": 2, "value": 1460,
                     "rows": [(170, 90, 80, 12, 960), (80, 100, 0, 25, 0),
                              (160, 180, 0, 1, 0), (60, 70, 0, 10, 0),
                              (30, 20, 10, 50, 500), (20, 30, 0, 15, 0)]},
            "low": {"demand": [32, 24, 16], "count": 2, "value": 752,
                    "rows": [(136, 90, 46, 12, 552), (64, 100, 0, 25, 0),
                             (128, 180, 0, 1, 0), (48, 70, 0, 10, 0),
                             (24, 20, 4, 50, 200), (16, 30, 0, 15, 0)]},
            "high": {"demand": [48, 36, 24], "count": 4, "value": 2200,
                     "rows": [(204, 90, 114, 12, 1368), (96, 100, 0, 25, 0),
                              (192, 180, 12, 1, 12), (72, 70, 2, 10, 20),
                              (36, 20, 16, 50, 800), (24, 30, 0, 15, 0)]},
        }
        fields = ("required_qty", "available_qty", "shortage_qty", "unit_cost", "shortage_value")
        for scenario, snapshot in expected.items():
            with self.subTest(scenario=scenario):
                response = self.client.get("/api/kpis/", {"scenario": scenario})
                self.assertEqual(response.status_code, 200)
                result = response.json()
                self.assertEqual(result, calculate(apply_scenario(self.data, scenario)))
                self.assertEqual([row["component_id"] for row in result["components"]],
                                 ["C01", "C02", "C03", "C04", "C05", "C06"])
                self.assertEqual([tuple(row[field] for field in fields) for row in result["components"]],
                                 snapshot["rows"])
                self.assertEqual([row["demand_qty"] for row in result["products"]], snapshot["demand"])
                self.assertEqual([row["has_shortage"] for row in result["products"]], [True, True, False])
                self.assertEqual(result["kpis"]["shortage_parts"], snapshot["count"])
                self.assertEqual(result["kpis"]["shortage_value"], snapshot["value"])
                self.assertEqual(result["kpis"]["affected_products"], 2)
                self.assertEqual(result["kpis"]["products_without_shortage_exposure"], 1)
                self.assertEqual(result["metadata"]["scenario"], scenario)
                self.assertEqual(result["metadata"]["demand_multiplier"],
                                 {"base": 1, "low": 0.8, "high": 1.2}[scenario])

    def test_unsupported_scenario_returns_400(self):
        for scenario in ["", "unknown", "HIGH", "1.2"]:
            with self.subTest(scenario=scenario):
                response = self.client.get("/api/kpis/", {"scenario": scenario})
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.json(), {"error": "scenario must be base, low, or high"})
        for scenario in [None, 1.2, True, [], {}]:
            with self.subTest(scenario=scenario), self.assertRaises(ValueError):
                apply_scenario(self.data, scenario)

    def test_scenario_rounding_uses_half_up_and_preserves_input(self):
        for scenario, original, expected in [("base", 2.5, 3), ("low", 1.875, 2), ("high", 1.25, 2)]:
            with self.subTest(scenario=scenario):
                data = deepcopy(self.data)
                data["products"][0]["demand_qty"] = original
                scenario_data = apply_scenario(data, scenario)
                self.assertEqual(scenario_data["products"][0]["demand_qty"], expected)
                self.assertEqual(data["products"][0]["demand_qty"], original)
                self.assertNotIn("scenario", data)

    def test_read_only_endpoints_and_health(self):
        self.assertEqual(self.client.get("/health/").json()["status"], "ok")
        self.assertEqual(self.client.post("/api/kpis/", {}).status_code, 405)
        self.assertEqual(self.client.post("/health/", {}).status_code, 405)

    def test_zero_demand_cannot_create_negative_shortage(self):
        for product in self.data["products"]:
            product["demand_qty"] = 0
        result = calculate(self.data)
        self.assertEqual(result["kpis"]["shortage_value"], 0)
        self.assertEqual(result["kpis"]["shortage_parts"], 0)
        self.assertEqual(result["kpis"]["affected_products"], 0)
        self.assertFalse(any(row["has_shortage"] for row in result["products"]))
        self.assertTrue(all(row["shortage_qty"] == 0 for row in result["components"]))

    def test_zero_demand_product_is_not_exposed_to_shared_component_shortage(self):
        self.data["products"][0]["demand_qty"] = 0
        self.data["components"][0]["on_hand"] = 50
        result = calculate(apply_scenario(self.data, "base"))
        self.assertEqual(result["components"][0]["shortage_qty"], 50)
        self.assertEqual([row["has_shortage"] for row in result["products"]], [False, True, False])
        self.assertEqual(result["kpis"]["affected_products"], 1)

    def test_missing_unknown_reference_and_duplicate_bom_are_rejected(self):
        for field, value in [("component_id", None), ("component_id", "unknown"), ("product_id", "unknown")]:
            with self.subTest(field=field, value=value):
                data = deepcopy(self.data)
                data["bom"][0][field] = value
                with self.assertRaises(ValueError):
                    calculate(data)
        self.data["bom"].append(deepcopy(self.data["bom"][0]))
        with self.assertRaisesMessage(ValueError, "Duplicate"):
            calculate(self.data)

    def test_invalid_bom_quantities_rejected(self):
        for value in [0, -1, "2", True, float("nan"), float("inf")]:
            with self.subTest(value=value):
                data = deepcopy(self.data)
                data["bom"][0]["qty_per"] = value
                with self.assertRaises(ValueError):
                    calculate(data)

    def test_bad_inventory_or_cost_rejected(self):
        for field, value in [("on_hand", -1), ("reserved", 101), ("reserved", -1), ("unit_cost", float("inf")), ("on_hand", "100")]:
            with self.subTest(field=field, value=value):
                data = deepcopy(self.data)
                data["components"][0][field] = value
                with self.assertRaises(ValueError):
                    calculate(data)

    def test_bad_demand_units_revision_and_duplicate_ids_rejected(self):
        for kind in ["negative_demand", "infinite_demand", "unit", "revision", "duplicate"]:
            with self.subTest(kind=kind):
                data = deepcopy(self.data)
                if kind == "negative_demand": data["products"][0]["demand_qty"] = -1
                elif kind == "infinite_demand": data["products"][0]["demand_qty"] = float("nan")
                elif kind == "unit": data["components"][0]["unit"] = "KG"
                elif kind == "revision": data["revision_status"] = "draft"
                else: data["components"].append(deepcopy(data["components"][0]))
                with self.assertRaises(ValueError):
                    calculate(data)

    def test_host_validation_blocks_unapproved_host(self):
        self.assertEqual(self.client.get("/api/kpis/", HTTP_HOST="external.example").status_code, 400)
