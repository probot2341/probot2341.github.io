"""Reproduce the offered case-study scenarios in Python and JavaScript."""
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

from bom_demo.logic import apply_scenario, calculate, load_sample


ROOT = Path(__file__).resolve().parent
FIELDS = ("component_id", "name", "required_qty", "available_qty", "shortage_qty", "unit_cost", "shortage_value")
EXPECTED = {
    "base": {"required": [170, 80, 160, 60, 30, 20], "short": [80, 0, 0, 0, 10, 0], "value": 1460},
    "low": {"required": [136, 64, 128, 48, 24, 16], "short": [46, 0, 0, 0, 4, 0], "value": 752},
    "high": {"required": [204, 96, 192, 72, 36, 24], "short": [114, 0, 12, 2, 16, 0], "value": 2200},
}


def normalized(result):
    return {"components": [{key: row[key] for key in FIELDS} for row in result["components"]],
            "products": result["products"], "kpis": result["kpis"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node", default="node", help="Node.js executable")
    args = parser.parse_args()
    data = load_sample()
    cases = [{"id": key, "data": data, "scenario": key} for key in EXPECTED]
    zero = deepcopy(data)
    zero["products"][0]["demand_qty"] = 0
    zero["products"][1]["demand_qty"] = 100
    cases.append({"id": "zero_demand", "data": zero, "scenario": "base"})
    rounding = deepcopy(data)
    rounding["products"][0]["demand_qty"] = 0.5
    cases.append({"id": "half_up_rounding", "data": rounding, "scenario": "base"})
    js = """const fs=require('node:fs');
const {calculateLearningCase}=require(process.argv[1]);
const cases=JSON.parse(fs.readFileSync(0,'utf8'));
process.stdout.write(JSON.stringify(Object.fromEntries(cases.map(c=>[c.id,calculateLearningCase(c.data,c.scenario)]))));"""
    browser = json.loads(subprocess.run(
        [args.node, "-e", js, str(ROOT / "browser_calculation.js")],
        input=json.dumps(cases), capture_output=True, text=True, check=True).stdout)
    results = {}
    for case in cases:
        actual = calculate(apply_scenario(case["data"], case["scenario"]))
        assert normalized(actual) == normalized(browser[case["id"]]), case["id"]
        if case["id"] in EXPECTED:
            expected = EXPECTED[case["id"]]
            assert [row["required_qty"] for row in actual["components"]] == expected["required"]
            assert [row["shortage_qty"] for row in actual["components"]] == expected["short"]
            assert actual["kpis"]["shortage_value"] == expected["value"]
            assert [row["available_qty"] for row in actual["components"]] == [90, 100, 180, 70, 20, 30]
            assert [row["unit_cost"] for row in actual["components"]] == [12, 25, 1, 10, 50, 15]
            assert actual["products"] == [
                {"product_id": name, "demand_qty": qty, "has_shortage": short}
                for name, qty, short in zip(["FG-A", "FG-B", "FG-C"],
                    {"base": [40, 30, 20], "low": [32, 24, 16], "high": [48, 36, 24]}[case["id"]],
                    [True, True, False])]
            results[case["id"]] = {"status": "passed", **normalized(actual)}
        elif case["id"] == "zero_demand":
            assert actual["products"][0]["has_shortage"] is False
            assert actual["kpis"]["affected_products"] == 1
        else:
            assert actual["products"][0]["demand_qty"] == 1
    evidence = {
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "data_scope": "Independent illustrative case study; fixed sample inputs",
        "input_sha256": hashlib.sha256((ROOT / "bom_demo/sample_bom.json").read_bytes()).hexdigest(),
        "browser_calculation_sha256": hashlib.sha256((ROOT / "browser_calculation.js").read_bytes()).hexdigest(),
        "python_test_evidence": "Technical_Test_Report.txt",
        "cross_language_checks": {"offered_scenarios": 3, "edge_cases": 2, "result": "passed"},
        "rounding": "Product demand rounds to whole units; .5 rounds up",
        "reservations": "Committed to other demand outside the modeled plan",
        "scenarios": results,
    }
    (ROOT / "Scenario_Verification.json").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print("PASS: 3 manual scenario checks and 5 Python/JavaScript comparisons (including 2 edge cases)")


if __name__ == "__main__":
    main()
