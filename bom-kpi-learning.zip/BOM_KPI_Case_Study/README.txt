BOM to KPI: independent planning case study

An illustrative case-study example created on October 22, 2026 to turn a bill
of materials into a material-shortage planning snapshot. All products, BOM lines,
stock, reservations, and prices are synthetic. It is an independent project,
separate from employer work. The calculation API is implemented; Power BI and
Azure DevOps material describes proposed next steps.

Requires Python 3.12+ and packages in requirements.txt. From this folder:
  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
  .venv\Scripts\python manage.py test bom_demo -v 2
  .venv\Scripts\python manage.py runserver 127.0.0.1:8770 --noreload

GET http://127.0.0.1:8770/health/ returns the local service status.
GET http://127.0.0.1:8770/api/kpis/ returns the base snapshot by default.
GET http://127.0.0.1:8770/api/kpis/?scenario=base uses original demand.
GET http://127.0.0.1:8770/api/kpis/?scenario=low uses 80% of original demand.
GET http://127.0.0.1:8770/api/kpis/?scenario=high uses 120% of original demand.
Other scenario values return HTTP 400 with a JSON error. Scenario names are
case-sensitive. Each scenario starts from the same original sample, not another
scenario result. Demand is scaled with decimal arithmetic and rounded per
finished product to the nearest whole unit, with a .5 tie rounding upward.

This API has GET-only endpoints, no login, no writes, and no database. Bind only
to loopback. It uses Django's development server and is not a production service.

Input: bom_demo/sample_bom.json. Output snapshot: sample_kpis.json.
Scope: single approved revision B, one level, EA units, USD. Required quantity
equals sum of demand x quantity-per across all products BEFORE joining stock.
Reserved stock represents commitments OUTSIDE this production plan. This avoids
subtracting stock already committed to the same demand a second time.
Available quantity = on-hand - reserved. Shortage = max(required - available, 0).
Shortage value = shortage x unit cost. It is planning exposure, not savings,
lost revenue, an approved purchase, or a supplier quote.

Expected snapshot: C01 requires 170, has 90 available, shortage 80. C05 requires
30, has 20 available, shortage 10. C01 value 960 + C05 value 500 = USD 1,460.
Two of six components are short. FG-A and FG-B contain globally short components;
FG-C has none. The KPI products_without_shortage_exposure is therefore 1.
This identifies product exposure under the combined plan, not how shared stock
would be allocated or the maximum feasible build quantity. Zero-demand products
are not marked as exposed even if they use a component short for other products.

Scenario       FG-A / FG-B / FG-C demand    Short components    Shortage value
Base                    40 / 30 / 20              2                USD 1,460
Low (-20%)              32 / 24 / 16              2                USD   752
High (+20%)             48 / 36 / 24              4                USD 2,200
The high scenario additionally makes C03 and C04 short. All three scenarios
expose FG-A and FG-B; FG-C has no shortage exposure in this sample.

API output includes scenario metadata, demand multiplier, rounding rule,
reservation assumption, component quantities/values, product exposure, and KPIs.
sample_kpis.json is the base result. Technical_Test_Report.txt records the actual
test runner output. The tests check all component outputs in each scenario,
shared-component aggregation, zero demand, rounding, invalid inputs/scenarios,
GET-only behavior, and local-host validation. These are technical checks, not
business-user acceptance testing or sign-off.

Validation rejects duplicate IDs and BOM lines; missing or unknown references;
nonfinite, boolean, string, negative or nonpositive quantities as appropriate;
negative stock or cost; stock over-reservation; unsupported units and revision.
Sample checks are not business approval or sign-off. Planning does not model
lead times, due dates, supply orders, substitutes, multilevel explosion or MRP.

The proposed Power BI report and prepared backlog/test examples are designs.
No .pbix report, Power BI refresh, Azure DevOps board, ERP integration, or business
UAT has been executed. The public portfolio demonstration runs in the browser;
GitHub Pages does not host this Python service.

Current Django documentation consulted through Context7:
https://docs.djangoproject.com/en/5.2/ref/request-response/#jsonresponse-objects
https://docs.djangoproject.com/en/5.2/topics/http/decorators/#allowed-http-methods
https://docs.djangoproject.com/en/5.2/topics/testing/tools/#simpletestcase
https://docs.djangoproject.com/en/5.2/ref/settings/#allowed-hosts

REPRODUCING THE BROWSER/PYTHON MATH CHECKS
Install Node.js, then run python verify_scenarios.py (or --node path-to-node).
The included browser_calculation.js is the same calculation shipped on the site.
Scenario_Verification.json records the input/code hashes and actual comparisons.
The three displayed totals are also checked against independently specified
per-component requirements, stock availability, unit costs, and shortages.

REPRODUCING THE BROWSER/PYTHON MATH CHECKS
Install Node.js, then run python verify_scenarios.py (or --node path-to-node).
The included browser_calculation.js is the same calculation shipped on the site.
Scenario_Verification.json records the input/code hashes and actual comparisons.
The three displayed totals are also checked against independently specified
per-component requirements, stock availability, unit costs, and shortages.
