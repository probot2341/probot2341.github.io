from copy import deepcopy
from django.test import SimpleTestCase, override_settings
from .logic import calculate, load_sample


@override_settings(ALLOWED_HOSTS=["localhost", "127.0.0.1", "[::1]", "testserver"])
class BomTests(SimpleTestCase):
    def setUp(self):
        self.data = load_sample()

    def test_api_expected_snapshot_and_shared_component_aggregation(self):
        response = self.client.get("/api/kpis/")
        self.assertEqual(response.status_code, 200)
        result = response.json()
        self.assertEqual(result["kpis"], {"bom_lines": 8, "component_count": 6,
            "shortage_parts": 2, "affected_products": 2, "product_count": 3,
            "fully_covered_products": 1, "shortage_value": 1460})
        c01 = result["components"][0]
        self.assertEqual((c01["required_qty"], c01["available_qty"], c01["shortage_qty"]), (170, 90, 80))
        self.assertEqual([row["has_shortage"] for row in result["products"]], [True, True, False])

    def test_read_only_endpoints_and_health(self):
        self.assertEqual(self.client.get("/health/").json()["status"], "ok")
        self.assertEqual(self.client.post("/api/kpis/", {}).status_code, 405)
        self.assertEqual(self.client.post("/health/", {}).status_code, 405)

    def test_zero_demand_cannot_create_negative_shortage(self):
        for product in self.data["products"]:
            product["demand_qty"] = 0
        result = calculate(self.data)
        self.assertEqual(result["kpis"]["shortage_value"], 0)
        self.assertEqual(result["kpis"]["shortage_parts"], 0)
        self.assertTrue(all(row["shortage_qty"] == 0 for row in result["components"]))

    def test_missing_unknown_reference_and_duplicate_bom_are_rejected(self):
        for field, value in [("component_id", None), ("component_id", "unknown"), ("product_id", "unknown")]:
            with self.subTest(field=field, value=value):
                data = deepcopy(self.data)
                data["bom"][0][field] = value
                with self.assertRaises(ValueError):
                    calculate(data)
        self.data["bom"].append(deepcopy(self.data["bom"][0]))
        with self.assertRaisesMessage(ValueError, "Duplicate"):
            calculate(self.data)

    def test_invalid_bom_quantities_rejected(self):
        for value in [0, -1, "2", True, float("nan"), float("inf")]:
            with self.subTest(value=value):
                data = deepcopy(self.data)
                data["bom"][0]["qty_per"] = value
                with self.assertRaises(ValueError):
                    calculate(data)

    def test_bad_inventory_or_cost_rejected(self):
        for field, value in [("on_hand", -1), ("reserved", 101), ("reserved", -1), ("unit_cost", float("inf")), ("on_hand", "100")]:
            with self.subTest(field=field, value=value):
                data = deepcopy(self.data)
                data["components"][0][field] = value
                with self.assertRaises(ValueError):
                    calculate(data)

    def test_bad_demand_units_revision_and_duplicate_ids_rejected(self):
        for kind in ["negative_demand", "infinite_demand", "unit", "revision", "duplicate"]:
            with self.subTest(kind=kind):
                data = deepcopy(self.data)
                if kind == "negative_demand": data["products"][0]["demand_qty"] = -1
                elif kind == "infinite_demand": data["products"][0]["demand_qty"] = float("nan")
                elif kind == "unit": data["components"][0]["unit"] = "KG"
                elif kind == "revision": data["revision_status"] = "draft"
                else: data["components"].append(deepcopy(data["components"][0]))
                with self.assertRaises(ValueError):
                    calculate(data)

    def test_host_validation_blocks_unapproved_host(self):
        self.assertEqual(self.client.get("/api/kpis/", HTTP_HOST="external.example").status_code, 400)
