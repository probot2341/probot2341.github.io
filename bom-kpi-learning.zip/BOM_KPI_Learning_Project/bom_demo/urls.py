from django.http import JsonResponse
from django.urls import path
from django.views.decorators.http import require_GET
from .logic import calculate, load_sample


@require_GET
def kpis(request):
    return JsonResponse(calculate(load_sample()))


@require_GET
def health(request):
    return JsonResponse({"status": "ok", "scope": "local educational prototype"})


urlpatterns = [path("api/kpis/", kpis), path("health/", health)]
