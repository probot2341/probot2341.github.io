BOM to KPI: local learning prototype

Created for interview preparation on October 22, 2026. All products, BOM lines,
stock, and prices are synthetic. This is a new educational project, not an
Innotek, Caterpillar, or other employer deliverable. It is not evidence of past
Power BI work, Azure DevOps use, stakeholder interviews, UAT, or production impact.

Requires Python 3.12+ and packages in requirements.txt. From this folder:
  python -m venv .venv
  .venv\Scripts\python -m pip install -r requirements.txt
  .venv\Scripts\python manage.py test bom_demo -v 2
  .venv\Scripts\python manage.py runserver 127.0.0.1:8770 --noreload

Visit http://127.0.0.1:8770/health/ and http://127.0.0.1:8770/api/kpis/.
This API has GET-only endpoints, no login, no writes, and no database. Bind only
to loopback. It uses Django's development server and is not a production service.

Input: bom_demo/sample_bom.json. Output snapshot: sample_kpis.json.
Scope: single approved revision B, one level, EA units, USD. Required quantity
equals sum of demand x quantity-per across all products BEFORE joining stock.
Available quantity = on-hand - reserved. Shortage = max(required - available, 0).
Shortage value = shortage x unit cost. It is planning exposure, not savings.

Expected snapshot: C01 requires 170, has 90 available, shortage 80. C05 requires
30, has 20 available, shortage 10. C01 value 960 + C05 value 500 = USD 1,460.
Two of six parts are short. FG-A and FG-B contain globally short components;
FG-C has none. Thus one of three assemblies has fully covered requirements at
this aggregate demand snapshot. No shared stock allocation or maximum buildable
quantity calculation is implemented. Zero-demand products are not marked at risk.

Validation rejects duplicate IDs and BOM lines; missing or unknown references;
nonfinite, boolean, string, negative or nonpositive quantities as appropriate;
negative stock or cost; stock over-reservation; unsupported units and revision.
Sample checks are not business approval or sign-off. Planning does not model
lead times, due dates, supply orders, substitutes, multilevel explosion or MRP.

The proposed Power BI report and prepared backlog/test examples in the portfolio
are learning designs. No Power BI report or Azure DevOps service is connected.

Current Django documentation consulted through Context7:
https://docs.djangoproject.com/en/5.2/ref/request-response/#jsonresponse-objects
https://docs.djangoproject.com/en/5.2/topics/http/decorators/#allowed-http-methods
https://docs.djangoproject.com/en/5.2/topics/testing/tools/#simpletestcase
https://docs.djangoproject.com/en/5.2/ref/settings/#allowed-hosts
